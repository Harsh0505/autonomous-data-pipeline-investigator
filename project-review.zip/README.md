# Retail Pipeline Guardian — Day 1

A production-oriented foundation for an autonomous data-pipeline repair system. This Day 1 MVP
simulates sales feeds from three regional suppliers, enforces data contracts, detects statistical
price anomalies, and emits machine-readable incident reports. It deliberately excludes LLM agents,
LangGraph orchestration, the API, and the frontend; the stable pipeline and report interfaces are
ready for those layers to consume later.

## What is included

- Reproducible sales data with supplier, category, geography, currency, price, quantity, and event time
- Ingestion from pandas data frames and CSV files
- Contract validation, GBP normalization, and daily supplier/category aggregation
- Six reproducible failures: schema change, duplicates, currency mismatch, missing values,
  unexpected categories, and delayed delivery
- Nine quality checks, including category-aware price z-score detection
- Versioned JSON incident reports with failure evidence and pipeline metrics
- A command-line scenario runner and a comprehensive pytest suite

## Requirements and setup

Python 3.11 or newer is required. The repository includes `uv.lock`; with
[uv](https://docs.astral.sh/uv/) installed, the reproducible setup is:

```powershell
uv sync --extra dev --python 3.12
.\.venv\Scripts\Activate.ps1
```

Alternatively, from this repository root in PowerShell using a standard Python installation:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
```

On macOS or Linux, activate with `source .venv/bin/activate` instead.

## Run the examples

List every scenario:

```powershell
retail-guardian list-scenarios
```

Run the healthy pipeline:

```powershell
retail-guardian run --scenario healthy --rows 500 --seed 42 --output-dir artifacts
```

Run one corrupted feed with a fixed clock for byte-for-byte reproducible inputs and incident IDs:

```powershell
retail-guardian run --scenario currency_mismatch --rows 500 --seed 42 `
  --as-of 2026-10-20T12:00:00Z --output-dir artifacts
```

Available failure scenarios are `schema_change`, `duplicate_records`, `currency_mismatch`,
`missing_values`, `unexpected_categories`, and `delayed_data`. Use `all_failures` to combine all six.

The command prints the report JSON, writes `<scenario>-incident.json`, and, for a healthy run,
writes `<scenario>-aggregates.csv`. Incident scenarios intentionally return exit code 1 so the CLI
works naturally in schedulers and CI. Usage errors return exit code 2.

## Run quality checks

```powershell
pytest
ruff check .
```

For a coverage report:

```powershell
pytest --cov=retail_guardian --cov-report=term-missing
```

## Project structure

```text
src/retail_guardian/
  config.py       Supplier contracts, category baselines, and runtime configuration
  synthetic.py    Seeded realistic sales generation
  failures.py     Reproducible failure injection
  quality.py      Deterministic and statistical checks
  pipeline.py     Ingestion, validation gate, transformation, aggregation, incident output
  scenarios.py    End-to-end example scenarios
  cli.py          Command-line interface
tests/            Healthy, corrupted, boundary, serialization, and CLI tests
```

`IncidentReport.schema_version` is the compatibility boundary for downstream agents and the future
FastAPI service. Quality findings contain a stable check ID, detection type, severity, affected-row
count, examples, and check-specific context. Repair agents can therefore investigate incidents
without parsing log text.
