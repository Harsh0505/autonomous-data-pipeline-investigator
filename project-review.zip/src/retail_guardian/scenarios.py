from __future__ import annotations

from datetime import datetime

from retail_guardian.config import PipelineConfig
from retail_guardian.failures import FailureType, inject_all_failures, inject_failure
from retail_guardian.pipeline import PipelineRun, RetailSalesPipeline
from retail_guardian.synthetic import SyntheticSalesGenerator

HEALTHY_SCENARIO = "healthy"
ALL_FAILURES_SCENARIO = "all_failures"
SCENARIOS = (HEALTHY_SCENARIO, *(item.value for item in FailureType), ALL_FAILURES_SCENARIO)


def run_scenario(
    scenario: str,
    *,
    row_count: int = 500,
    seed: int = 42,
    as_of: datetime,
    config: PipelineConfig | None = None,
) -> PipelineRun:
    if scenario not in SCENARIOS:
        raise ValueError(f"unknown scenario: {scenario}")

    pipeline_config = config or PipelineConfig()
    frame = SyntheticSalesGenerator(pipeline_config).generate(row_count, seed=seed, as_of=as_of)
    injections = []
    if scenario == ALL_FAILURES_SCENARIO:
        frame, injections = inject_all_failures(frame, seed=seed)
    elif scenario != HEALTHY_SCENARIO:
        frame, injection = inject_failure(frame, FailureType(scenario), seed=seed)
        injections = [injection]

    return RetailSalesPipeline(pipeline_config).run(
        frame, scenario=scenario, as_of=as_of, injections=injections
    )
