from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from datetime import UTC, datetime
from pathlib import Path

from retail_guardian.scenarios import SCENARIOS, run_scenario


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="retail-guardian",
        description="Run reproducible retail data-pipeline scenarios.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    run_parser = subparsers.add_parser("run", help="Generate and execute a pipeline scenario")
    run_parser.add_argument("--scenario", choices=SCENARIOS, default="healthy")
    run_parser.add_argument("--rows", type=int, default=500)
    run_parser.add_argument("--seed", type=int, default=42)
    run_parser.add_argument(
        "--as-of",
        type=_parse_datetime,
        default=None,
        help="ISO-8601 reference time (default: current UTC time)",
    )
    run_parser.add_argument("--output-dir", type=Path, default=Path("artifacts"))
    subparsers.add_parser("list-scenarios", help="List available example scenarios")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "list-scenarios":
        print("\n".join(SCENARIOS))
        return 0

    as_of = args.as_of or datetime.now(UTC)
    try:
        run = run_scenario(args.scenario, row_count=args.rows, seed=args.seed, as_of=as_of)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    output_dir: Path = args.output_dir
    report_path = output_dir / f"{args.scenario}-incident.json"
    run.report.write(report_path)
    if run.aggregates is not None:
        output_dir.mkdir(parents=True, exist_ok=True)
        run.aggregates.to_csv(output_dir / f"{args.scenario}-aggregates.csv", index=False)

    print(run.report.to_json())
    print(f"Report written to {report_path}", file=sys.stderr)
    return 0 if run.report.status == "healthy" else 1


def _parse_datetime(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise argparse.ArgumentTypeError("--as-of must include a timezone")
    return parsed


if __name__ == "__main__":
    raise SystemExit(main())
